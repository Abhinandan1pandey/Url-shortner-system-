#pragma once
#include <string>
#include <unordered_map>

class UrlShortener {
public:
    UrlShortener();
    std::string shorten(const std::string& longUrl, const std::string& algo);
    std::string retrieve(const std::string& shortCode);
private:
    std::unordered_map<std::string, std::string> codeToUrl;
    std::unordered_map<std::string, std::string> urlToCode;
    std::string hashUrl(const std::string& url, int attempt, const std::string& algo);
    static const std::string chars;
}; 